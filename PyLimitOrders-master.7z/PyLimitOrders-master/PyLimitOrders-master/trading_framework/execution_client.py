from typing import Protocol

class ExecutionException(Exception):
    """Custom exception for execution-related errors."""
    pass

class ExecutionClient(Protocol):
    def buy(self, product_id: str, amount: int) -> None:
        """
        Execute a buy order. Throws ExecutionException on failure.

        :param product_id: The product to buy.
        :param amount: The amount to buy.
        :return: None
        """
        raise NotImplementedError

    def sell(self, product_id: str, amount: int) -> None:
        """
        Execute a sell order. Throws ExecutionException on failure.

        :param product_id: The product to sell.
        :param amount: The amount to sell.
        :return: None
        """
        raise NotImplementedError